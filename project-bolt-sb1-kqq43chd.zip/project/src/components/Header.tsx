import { useState, useEffect } from 'react';
import { Menu, X, Search } from 'lucide-react';
import Logo from './Logo';

const navItems = [
  { label: 'Home', href: '#home' },
  { label: 'Match Coverage', href: '#match' },
  { label: 'Transfer News', href: '#transfers' },
  { label: 'Player Stories', href: '#players' },
  { label: 'Football Culture', href: '#culture' },
  { label: 'Analysis', href: '#analysis' },
  { label: 'Video', href: '#video' },
];

export default function Header() {
  const [isMobileOpen, setIsMobileOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 10);
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    if (isMobileOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [isMobileOpen]);

  return (
    <>
      <header
        className={`sticky top-0 z-50 bg-ink-black transition-shadow duration-300 ${
          isScrolled ? 'shadow-lg shadow-black/40' : ''
        }`}
      >
        <div className="container-main">
          <div className="flex h-16 items-center justify-between gap-4 lg:h-20">
            <a
              href="#home"
              className="focus-visible-ring rounded-md"
              aria-label="Victor's Football Lens — Home"
            >
              <Logo />
            </a>

            <nav
              className="hidden items-center gap-7 lg:flex"
              aria-label="Primary navigation"
            >
              {navItems.map((item) => (
                <a key={item.label} href={item.href} className="nav-link focus-visible-ring rounded-sm">
                  {item.label}
                </a>
              ))}
            </nav>

            <div className="flex items-center gap-3">
              <button
                className="hidden h-10 w-10 items-center justify-center rounded-md text-paper-200 transition-colors hover:bg-ink-800 hover:text-white focus-visible-ring sm:flex"
                aria-label="Search articles"
              >
                <Search size={20} />
              </button>

              <button
                onClick={() => setIsMobileOpen((prev) => !prev)}
                className="flex h-10 w-10 items-center justify-center rounded-md text-white transition-colors hover:bg-ink-800 focus-visible-ring lg:hidden"
                aria-label={isMobileOpen ? 'Close menu' : 'Open menu'}
                aria-expanded={isMobileOpen}
                aria-controls="mobile-nav"
              >
                {isMobileOpen ? <X size={24} /> : <Menu size={24} />}
              </button>
            </div>
          </div>
        </div>

        <div className="h-0.5 w-full bg-gradient-to-r from-brand-red via-brand-red-light to-brand-red" />
      </header>

      {isMobileOpen && (
        <div
          id="mobile-nav"
          className="fixed inset-0 z-40 bg-ink-black/95 backdrop-blur-sm lg:hidden"
          role="dialog"
          aria-modal="true"
          aria-label="Mobile navigation menu"
        >
          <div className="flex flex-col gap-2 px-6 pt-24 pb-8 animate-slide-down">
            {navItems.map((item) => (
              <a
                key={item.label}
                href={item.href}
                onClick={() => setIsMobileOpen(false)}
                className="border-b border-ink-800 py-4 font-display text-xl font-semibold uppercase tracking-wide text-paper-200 transition-colors hover:text-white focus-visible-ring rounded-sm"
              >
                {item.label}
              </a>
            ))}
            <button
              className="mt-4 flex items-center gap-3 rounded-md bg-ink-800 px-4 py-3 text-paper-200 transition-colors hover:text-white focus-visible-ring"
              aria-label="Search articles"
            >
              <Search size={20} />
              <span className="text-sm font-semibold uppercase tracking-wide">Search</span>
            </button>
          </div>
        </div>
      )}
    </>
  );
}
