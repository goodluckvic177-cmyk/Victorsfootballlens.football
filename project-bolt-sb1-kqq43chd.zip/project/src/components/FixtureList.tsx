import { Calendar, ChevronRight } from 'lucide-react';
import type { Fixture } from '@/data/content';

interface FixtureListProps {
  fixtures: Fixture[];
}

export default function FixtureList({ fixtures }: FixtureListProps) {
  return (
    <section
      className="bg-ink-950 py-12 lg:py-16"
      aria-label="Upcoming fixtures"
    >
      <div className="container-main">
        <div className="mb-8 flex items-center gap-3">
          <Calendar size={20} className="text-brand-red" />
          <h2 className="font-display text-2xl font-bold uppercase tracking-tight text-white">
            Upcoming Fixtures
          </h2>
          <span className="rounded-full bg-ink-800 px-3 py-1 text-xs font-medium text-paper-300">
            Fictional sample data
          </span>
        </div>

        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          {fixtures.map((fixture) => (
            <div
              key={fixture.id}
              className="group flex items-center justify-between rounded-lg border border-ink-800 bg-ink-900 p-4 transition-all duration-200 hover:border-brand-red/40 hover:bg-ink-800"
            >
              <div className="flex flex-col gap-1">
                <div className="flex items-center gap-2 text-sm font-display font-semibold uppercase tracking-wide text-white">
                  <span>{fixture.homeTeam}</span>
                  <span className="text-brand-red">vs</span>
                  <span>{fixture.awayTeam}</span>
                </div>
                <span className="text-xs text-paper-300">
                  {fixture.competition} &middot; {fixture.dateLabel}
                </span>
              </div>
              <ChevronRight
                size={18}
                className="text-paper-300 transition-all duration-200 group-hover:translate-x-1 group-hover:text-brand-red"
              />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
