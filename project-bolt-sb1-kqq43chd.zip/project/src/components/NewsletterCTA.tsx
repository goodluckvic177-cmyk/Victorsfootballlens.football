import { Mail, Send, Info } from 'lucide-react';
import { useState } from 'react';

export default function NewsletterCTA() {
  const [email, setEmail] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      setSubmitted(true);
    }
  };

  return (
    <section
      id="newsletter"
      className="relative overflow-hidden bg-brand-red py-12 lg:py-16"
      aria-label="Newsletter signup"
    >
      <div className="container-main">
        <div className="flex flex-col items-center gap-6 text-center lg:flex-row lg:justify-between lg:text-left">
          <div className="flex flex-col items-center gap-3 lg:flex-row lg:gap-5 lg:items-start">
            <div className="flex h-14 w-14 items-center justify-center rounded-xl bg-white/15">
              <Mail size={28} className="text-white" />
            </div>
            <div className="max-w-xl">
              <h2 className="font-display text-2xl font-bold uppercase tracking-tight text-white sm:text-3xl">
                Never Miss a Story
              </h2>
              <p className="mt-2 text-sm leading-relaxed text-white/90 sm:text-base">
                Get the best of Victor's Football Lens delivered to your inbox —
                match reports, transfer updates, and exclusive analysis.
              </p>
            </div>
          </div>

          <div className="w-full max-w-md">
            {submitted ? (
              <div className="flex items-center gap-3 rounded-lg bg-white/15 px-5 py-4 text-white backdrop-blur-sm">
                <Info size={20} className="flex-shrink-0" />
                <p className="text-sm font-medium">
                  Thanks for your interest! Email delivery is not yet connected to a service.
                  We'll activate subscriptions soon.
                </p>
              </div>
            ) : (
              <form
                className="flex w-full gap-3"
                onSubmit={handleSubmit}
                aria-label="Newsletter signup form"
              >
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Your email address"
                  aria-label="Email address"
                  className="flex-1 rounded-md border-0 bg-white px-4 py-3 text-sm text-ink-900 placeholder:text-paper-300 focus:outline-none focus:ring-2 focus:ring-white"
                />
                <button
                  type="submit"
                  className="flex items-center gap-2 rounded-md bg-ink-black px-5 py-3 text-sm font-bold uppercase tracking-wider text-white transition-all duration-200 hover:bg-ink-900 active:scale-[0.98] focus-visible-ring"
                >
                  <Send size={16} />
                  <span className="hidden sm:inline">Subscribe</span>
                </button>
              </form>
            )}
            <p className="mt-2 text-xs text-white/70">
              Newsletter delivery coming soon — we'll notify you when subscriptions go live.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
