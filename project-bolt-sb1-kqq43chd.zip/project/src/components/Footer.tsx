import { Eye, Twitter, Instagram, Youtube, Facebook, Mail, MapPin } from 'lucide-react';
import Logo from './Logo';

const footerNav = [
  {
    title: 'Coverage',
    links: [
      { label: 'Match Coverage', href: '#match' },
      { label: 'Transfer News', href: '#transfers' },
      { label: 'Player Stories', href: '#players' },
      { label: 'Analysis', href: '#analysis' },
    ],
  },
  {
    title: 'More',
    links: [
      { label: 'Football Culture', href: '#culture' },
      { label: 'Video', href: '#video' },
      { label: 'Trending', href: '#trending' },
      { label: 'Newsletter', href: '#newsletter' },
    ],
  },
  {
    title: 'About',
    links: [
      { label: 'About Us', href: '#about' },
      { label: 'Editorial Team', href: '#editorial' },
      { label: 'Contact', href: '#contact' },
      { label: 'Advertise', href: '#advertise' },
    ],
  },
];

const socialLinks = [
  { icon: Twitter, label: 'Twitter', href: '#' },
  { icon: Instagram, label: 'Instagram', href: '#' },
  { icon: Youtube, label: 'YouTube', href: '#' },
  { icon: Facebook, label: 'Facebook', href: '#' },
  { icon: Mail, label: 'Email', href: '#contact' },
];

export default function Footer() {
  return (
    <footer className="bg-ink-black text-paper-200">
      <div className="h-0.5 w-full bg-gradient-to-r from-brand-red via-brand-red-light to-brand-red" />

      <div className="container-main py-14">
        <div className="grid grid-cols-1 gap-10 md:grid-cols-2 lg:grid-cols-4">
          <div className="lg:col-span-1">
            <Logo textClassName="text-white" />
            <p className="mt-4 max-w-xs text-sm leading-relaxed text-paper-300">
              See Beyond the Game. Football news, player stories, match coverage,
              transfer news, and football culture — from the pitch to the stands.
            </p>
            <div className="mt-6 flex gap-3">
              {socialLinks.map(({ icon: Icon, label, href }) => (
                <a
                  key={label}
                  href={href}
                  aria-label={label}
                  className="flex h-9 w-9 items-center justify-center rounded-md bg-ink-800 text-paper-300 transition-all duration-200 hover:bg-brand-red hover:text-white focus-visible-ring"
                >
                  <Icon size={18} />
                </a>
              ))}
            </div>
          </div>

          {footerNav.map((section) => (
            <div key={section.title}>
              <h3 className="font-display text-sm font-bold uppercase tracking-wider text-white">
                {section.title}
              </h3>
              <ul className="mt-4 space-y-3">
                {section.links.map((link) => (
                  <li key={link.label}>
                    <a
                      href={link.href}
                      className="text-sm text-paper-300 transition-colors hover:text-brand-red focus-visible-ring rounded-sm"
                    >
                      {link.label}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-10 flex flex-col gap-4 border-t border-ink-800 pt-8 lg:flex-row lg:items-center lg:justify-between">
          <div className="flex items-center gap-2 text-xs text-paper-300">
            <MapPin size={14} className="text-brand-red" />
            <span>victorsfootballlens.com — Football media for the global fan</span>
          </div>
          <div className="flex items-center gap-2 text-xs text-paper-300">
            <Eye size={14} className="text-brand-red" />
            <span className="font-display uppercase tracking-wider">See Beyond the Game</span>
          </div>
        </div>

        <div className="mt-6 flex flex-col items-center gap-4 border-t border-ink-800/50 pt-6 sm:flex-row sm:justify-between">
          <p className="text-xs text-paper-300">
            &copy; {new Date().getFullYear()} Victor's Football Lens. All rights reserved.
          </p>
          <div className="flex gap-5">
            <a href="#privacy" className="text-xs text-paper-300 hover:text-brand-red focus-visible-ring rounded-sm">
              Privacy Policy
            </a>
            <a href="#terms" className="text-xs text-paper-300 hover:text-brand-red focus-visible-ring rounded-sm">
              Terms of Use
            </a>
            <a href="#cookies" className="text-xs text-paper-300 hover:text-brand-red focus-visible-ring rounded-sm">
              Cookie Policy
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
