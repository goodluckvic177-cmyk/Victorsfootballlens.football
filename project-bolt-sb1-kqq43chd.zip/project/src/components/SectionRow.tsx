import { Radio, ArrowRight } from 'lucide-react';
import ArticleCard from './ArticleCard';
import type { Article } from '@/data/content';

interface SectionRowProps {
  id: string;
  title: string;
  subtitle?: string;
  articles: Article[];
  icon?: typeof Radio;
}

export default function SectionRow({
  id,
  title,
  subtitle,
  articles,
  icon: Icon,
}: SectionRowProps) {
  if (articles.length === 0) return null;

  const [main, ...rest] = articles;

  return (
    <section id={id} className="py-12 lg:py-16" aria-label={title}>
      <div className="container-main">
        <div className="mb-8 flex items-end justify-between border-b border-paper-200 pb-4">
          <div>
            <div className="mb-2 flex items-center gap-2">
              {Icon && <Icon size={18} className="text-brand-red" />}
              <span className="text-xs font-bold uppercase tracking-widest text-brand-red">
                {title}
              </span>
            </div>
            {subtitle && (
              <h2 className="font-display text-2xl font-bold uppercase tracking-tight text-ink-900 sm:text-3xl">
                {subtitle}
              </h2>
            )}
          </div>
          <a
            href="#all-articles"
            className="flex items-center gap-1 text-sm font-bold uppercase tracking-wider text-ink-700 transition-colors hover:text-brand-red focus-visible-ring rounded-sm"
          >
            More
            <ArrowRight size={14} />
          </a>
        </div>

        <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
          <ArticleCard article={main} className="lg:row-span-1" />
          <div className="flex flex-col gap-5">
            {rest.map((article) => (
              <ArticleCard
                key={article.id}
                article={article}
                variant="horizontal"
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
