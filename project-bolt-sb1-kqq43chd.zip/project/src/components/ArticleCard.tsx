import { Clock, PlayCircle } from 'lucide-react';
import type { Article } from '@/data/content';

const categoryTagColors: Record<string, string> = {
  'Match Coverage': 'tag-red',
  'Transfer News': 'tag-dark',
  'Player Stories': 'tag-light',
  'Football Culture': 'tag-outline',
  Analysis: 'tag-red',
  Video: 'tag-dark',
};

interface ArticleCardProps {
  article: Article;
  variant?: 'default' | 'horizontal' | 'compact';
  className?: string;
}

export default function ArticleCard({
  article,
  variant = 'default',
  className = '',
}: ArticleCardProps) {
  const tagClass = categoryTagColors[article.category] ?? 'tag-light';
  const isVideo = article.category === 'Video';

  if (variant === 'compact') {
    return (
      <a
        href={`#article-${article.id}`}
        className={`group flex gap-4 focus-visible-ring rounded-md ${className}`}
      >
        <div className="relative h-20 w-28 flex-shrink-0 overflow-hidden rounded-md bg-paper-100">
          <img
            src={article.image}
            alt={article.imageAlt}
            loading="lazy"
            className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
          />
        </div>
        <div className="flex flex-col justify-center">
          <span className="mb-1 text-xs font-bold uppercase tracking-wider text-brand-red">
            {article.category}
          </span>
          <h4 className="font-display text-sm font-semibold leading-snug text-ink-900 transition-colors group-hover:text-brand-red">
            {article.title}
          </h4>
        </div>
      </a>
    );
  }

  if (variant === 'horizontal') {
    return (
      <a
        href={`#article-${article.id}`}
        className={`group flex flex-col gap-4 sm:flex-row focus-visible-ring rounded-lg ${className}`}
      >
        <div className="relative h-56 flex-shrink-0 overflow-hidden rounded-lg bg-paper-100 sm:h-40 sm:w-56">
          <img
            src={article.image}
            alt={article.imageAlt}
            loading="lazy"
            className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
          />
          {isVideo && (
            <div className="absolute inset-0 flex items-center justify-center">
              <PlayCircle size={40} className="text-white drop-shadow-lg" />
            </div>
          )}
        </div>
        <div className="flex flex-col justify-center">
          <div className="mb-2 flex items-center gap-3">
            <span className={`tag ${tagClass}`}>{article.category}</span>
            {article.isFictional && (
              <span className="text-xs italic text-paper-300">Fictional sample</span>
            )}
          </div>
          <h3 className="article-title text-lg text-ink-900 transition-colors group-hover:text-brand-red">
            {article.title}
          </h3>
          <p className="mt-2 text-sm leading-relaxed text-paper-300 line-clamp-2">
            {article.excerpt}
          </p>
          <div className="mt-3 flex items-center gap-3 text-xs text-paper-300">
            <span className="font-semibold text-ink-700">{article.author}</span>
            <span>&middot;</span>
            <span>{article.date}</span>
            <span>&middot;</span>
            <span className="flex items-center gap-1">
              <Clock size={12} />
              {article.readTime}
            </span>
          </div>
        </div>
      </a>
    );
  }

  return (
    <a
      href={`#article-${article.id}`}
      className={`group flex flex-col overflow-hidden rounded-lg bg-white shadow-sm ring-1 ring-paper-200 transition-all duration-300 hover:shadow-xl hover:ring-paper-300 focus-visible-ring ${className}`}
    >
      <div className="relative h-56 overflow-hidden bg-paper-100">
        <img
          src={article.image}
          alt={article.imageAlt}
          loading="lazy"
          className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-ink-black/40 to-transparent opacity-0 transition-opacity duration-300 group-hover:opacity-100" />
        <div className="absolute top-3 left-3 flex items-center gap-2">
          <span className={`tag ${tagClass}`}>{article.category}</span>
          {article.isFictional && (
            <span className="rounded-full bg-white/90 px-2 py-0.5 text-[10px] italic font-medium text-ink-700">
              Fictional
            </span>
          )}
        </div>
        {isVideo && (
          <div className="absolute inset-0 flex items-center justify-center">
            <PlayCircle size={48} className="text-white drop-shadow-lg transition-transform duration-300 group-hover:scale-110" />
          </div>
        )}
      </div>

      <div className="flex flex-1 flex-col p-5">
        <h3 className="article-title text-lg text-ink-900 transition-colors group-hover:text-brand-red">
          {article.title}
        </h3>
        <p className="mt-2 flex-1 text-sm leading-relaxed text-paper-300 line-clamp-2">
          {article.excerpt}
        </p>
        <div className="mt-4 flex items-center justify-between border-t border-paper-200 pt-3">
          <span className="text-xs font-semibold text-ink-700">{article.author}</span>
          <span className="flex items-center gap-1 text-xs text-paper-300">
            <Clock size={12} />
            {article.readTime}
          </span>
        </div>
      </div>
    </a>
  );
}
