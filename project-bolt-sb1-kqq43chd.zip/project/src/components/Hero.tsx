import { ArrowRight, Clock, PlayCircle } from 'lucide-react';
import type { Article } from '@/data/content';

interface HeroProps {
  mainArticle: Article;
  sideArticles: Article[];
}

export default function Hero({ mainArticle, sideArticles }: HeroProps) {
  return (
    <section id="home" className="relative bg-ink-black" aria-label="Featured stories">
      <div className="container-main py-8 lg:py-12">
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
          <a
            href={`#article-${mainArticle.id}`}
            className="group relative col-span-1 flex min-h-[400px] flex-col justify-end overflow-hidden rounded-xl lg:min-h-[520px] focus-visible-ring"
          >
            <img
              src={mainArticle.image}
              alt={mainArticle.imageAlt}
              className="absolute inset-0 h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-ink-black via-ink-black/60 to-ink-black/10" />

            <div className="relative z-10 p-6 lg:p-8">
              <div className="mb-3 flex items-center gap-3">
                <span className="tag tag-red">{mainArticle.category}</span>
                {mainArticle.isFictional && (
                  <span className="text-xs italic text-paper-300">Fictional sample</span>
                )}
              </div>
              <h1 className="article-title text-2xl text-white sm:text-3xl lg:text-4xl">
                {mainArticle.title}
              </h1>
              <p className="mt-3 max-w-xl text-sm leading-relaxed text-paper-200 sm:text-base">
                {mainArticle.excerpt}
              </p>
              <div className="mt-5 flex items-center gap-4 text-xs text-paper-300">
                <span className="font-semibold text-white">{mainArticle.author}</span>
                <span>{mainArticle.date}</span>
                <span className="flex items-center gap-1">
                  <Clock size={12} />
                  {mainArticle.readTime}
                </span>
              </div>
              <div className="mt-5 inline-flex items-center gap-2 text-sm font-bold uppercase tracking-wider text-brand-red transition-all duration-200 group-hover:gap-3">
                Read Story
                <ArrowRight size={16} />
              </div>
            </div>
          </a>

          <div className="col-span-1 flex flex-col gap-4 lg:col-span-2">
            {sideArticles.map((article) => (
              <a
                key={article.id}
                href={`#article-${article.id}`}
                className="group relative flex min-h-[160px] flex-1 overflow-hidden rounded-xl focus-visible-ring"
              >
                <img
                  src={article.image}
                  alt={article.imageAlt}
                  className="absolute inset-0 h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-ink-black via-ink-black/50 to-transparent" />

                <div className="relative z-10 flex h-full flex-col justify-end p-5">
                  <div className="mb-2 flex items-center gap-2">
                    <span className="tag tag-red text-[10px]">{article.category}</span>
                    {article.isFictional && (
                      <span className="text-[10px] italic text-paper-300">Fictional</span>
                    )}
                  </div>
                  <h2 className="article-title text-lg text-white transition-colors group-hover:text-brand-red-light lg:text-xl">
                    {article.title}
                  </h2>
                  <div className="mt-2 flex items-center gap-3 text-xs text-paper-300">
                    <span className="font-semibold text-paper-200">{article.author}</span>
                    <span>{article.date}</span>
                    {article.category === 'Video' && (
                      <span className="flex items-center gap-1 text-brand-red-light">
                        <PlayCircle size={12} />
                        Watch
                      </span>
                    )}
                  </div>
                </div>
              </a>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
