import { Calendar, Clock, ChevronRight } from 'lucide-react';
import type { Fixture } from '@/data/content';

interface MatchCentreProps {
  fixtures: Fixture[];
}

export default function MatchCentre({ fixtures }: MatchCentreProps) {
  if (fixtures.length === 0) return null;

  return (
    <section
      id="match"
      className="bg-ink-950 py-12 lg:py-16"
      aria-label="Match centre"
    >
      <div className="container-main">
        <div className="mb-8 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <span className="mb-1 flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-brand-red">
              <Calendar size={14} />
              Match Centre
            </span>
            <h2 className="font-display text-2xl font-bold uppercase tracking-tight text-white sm:text-3xl lg:text-4xl">
              Upcoming Fixtures
            </h2>
          </div>
          <span className="rounded-full bg-ink-800 px-3 py-1 text-xs font-medium text-paper-300">
            Fictional sample data
          </span>
        </div>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          {fixtures.map((fixture) => (
            <div
              key={fixture.id}
              className="group rounded-xl border border-ink-800 bg-ink-900 p-5 transition-all duration-200 hover:border-brand-red/50 hover:bg-ink-800"
            >
              <div className="mb-4 flex items-center justify-between">
                <span className="rounded bg-ink-800 px-2.5 py-1 text-xs font-bold uppercase tracking-wider text-paper-300 group-hover:bg-ink-700">
                  {fixture.competition}
                </span>
                <span className="flex items-center gap-1 text-xs text-paper-300">
                  <Clock size={12} />
                  {fixture.dateLabel} — {fixture.timeLabel}
                </span>
              </div>

              <div className="flex items-center justify-between gap-4">
                <div className="flex flex-1 flex-col items-center text-center">
                  <div className="flex h-12 w-12 items-center justify-center rounded-full bg-ink-800 font-display text-lg font-bold text-white">
                    {fixture.homeTeam.charAt(0)}
                  </div>
                  <span className="mt-2 font-display text-sm font-semibold uppercase tracking-wide text-white">
                    {fixture.homeTeam}
                  </span>
                </div>

                <div className="flex flex-col items-center">
                  <span className="font-display text-xl font-bold text-brand-red">VS</span>
                  <span className="mt-1 text-xs text-paper-300">{fixture.timeLabel}</span>
                </div>

                <div className="flex flex-1 flex-col items-center text-center">
                  <div className="flex h-12 w-12 items-center justify-center rounded-full bg-ink-800 font-display text-lg font-bold text-white">
                    {fixture.awayTeam.charAt(0)}
                  </div>
                  <span className="mt-2 font-display text-sm font-semibold uppercase tracking-wide text-white">
                    {fixture.awayTeam}
                  </span>
                </div>
              </div>

              <a
                href={`#fixture-${fixture.id}`}
                className="mt-4 flex items-center justify-end gap-1 text-xs font-bold uppercase tracking-wider text-brand-red transition-all hover:gap-2 focus-visible-ring rounded-sm"
              >
                Preview
                <ChevronRight size={14} />
              </a>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
