import { Star, ArrowRight } from 'lucide-react';
import type { PlayerSpotlight as PlayerSpotlightType } from '@/data/content';

interface PlayerSpotlightProps {
  players: PlayerSpotlightType[];
}

export default function PlayerSpotlight({ players }: PlayerSpotlightProps) {
  if (players.length === 0) return null;

  return (
    <section
      id="players"
      className="bg-white py-12 lg:py-16"
      aria-label="Player spotlight"
    >
      <div className="container-main">
        <div className="mb-8 flex items-end justify-between border-b-2 border-ink-black pb-4">
          <div>
            <span className="mb-1 flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-brand-red">
              <Star size={14} fill="currentColor" />
              In Focus
            </span>
            <h2 className="font-display text-2xl font-bold uppercase tracking-tight text-ink-900 sm:text-3xl lg:text-4xl">
              Player Spotlight
            </h2>
          </div>
          <span className="hidden rounded-full bg-paper-100 px-3 py-1 text-xs font-medium text-paper-300 sm:block">
            Fictional profiles
          </span>
        </div>

        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {players.map((player) => (
            <article
              key={player.id}
              className="group overflow-hidden rounded-xl bg-paper-50 shadow-sm ring-1 ring-paper-200 transition-all duration-300 hover:shadow-xl hover:ring-paper-300"
            >
              <div className="relative aspect-[4/5] overflow-hidden bg-ink-900">
                <img
                  src={player.image}
                  alt={player.imageAlt}
                  loading="lazy"
                  className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-ink-black/80 via-transparent to-transparent" />
                <div className="absolute top-3 right-3">
                  <span className="rounded-full bg-brand-red px-3 py-1 text-xs font-bold uppercase tracking-wider text-white">
                    {player.role}
                  </span>
                </div>
                <div className="absolute bottom-0 left-0 right-0 p-5">
                  <h3 className="font-display text-2xl font-bold uppercase tracking-tight text-white">
                    {player.name}
                  </h3>
                  <p className="mt-1 text-sm leading-relaxed text-paper-200">
                    {player.tagline}
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-3 divide-x divide-paper-200 border-b border-paper-200">
                {player.stats.map((stat) => (
                  <div key={stat.label} className="flex flex-col items-center py-4">
                    <span className="font-display text-2xl font-bold text-brand-red">
                      {stat.value}
                    </span>
                    <span className="mt-1 text-xs font-medium uppercase tracking-wider text-paper-300">
                      {stat.label}
                    </span>
                  </div>
                ))}
              </div>

              <div className="p-4">
                <a
                  href={`#player-${player.id}`}
                  className="flex items-center justify-between text-sm font-bold uppercase tracking-wider text-ink-900 transition-colors hover:text-brand-red focus-visible-ring rounded-sm"
                >
                  Read Profile
                  <ArrowRight size={16} className="transition-transform duration-200 group-hover:translate-x-1" />
                </a>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
