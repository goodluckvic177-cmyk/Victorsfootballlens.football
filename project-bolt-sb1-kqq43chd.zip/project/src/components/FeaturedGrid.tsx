import { TrendingUp } from 'lucide-react';
import ArticleCard from './ArticleCard';
import type { Article } from '@/data/content';

interface FeaturedGridProps {
  articles: Article[];
}

export default function FeaturedGrid({ articles }: FeaturedGridProps) {
  if (articles.length === 0) return null;

  return (
    <section className="bg-paper-50 py-12 lg:py-16" aria-label="Editor's picks">
      <div className="container-main">
        <div className="mb-8 flex items-end justify-between">
          <div>
            <div className="mb-2 flex items-center gap-2">
              <TrendingUp size={18} className="text-brand-red" />
              <span className="text-xs font-bold uppercase tracking-widest text-brand-red">
                Editor's Picks
              </span>
            </div>
            <h2 className="font-display text-2xl font-bold uppercase tracking-tight text-ink-900 sm:text-3xl">
              This Week's Top Stories
            </h2>
          </div>
          <a
            href="#all-articles"
            className="hidden items-center gap-1 text-sm font-bold uppercase tracking-wider text-ink-700 transition-colors hover:text-brand-red focus-visible-ring rounded-sm sm:flex"
          >
            View All
          </a>
        </div>

        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {articles.map((article) => (
            <ArticleCard key={article.id} article={article} />
          ))}
        </div>
      </div>
    </section>
  );
}
