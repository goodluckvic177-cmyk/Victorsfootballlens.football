import { useState } from 'react';
import { Zap, X } from 'lucide-react';

interface BreakingNewsStripProps {
  message?: string;
  visible?: boolean;
}

export default function BreakingNewsStrip({
  message = 'No verified breaking news at this time — check back for live updates.',
  visible = false,
}: BreakingNewsStripProps) {
  const [dismissed, setDismissed] = useState(false);

  if (!visible || dismissed) return null;

  return (
    <div className="relative z-30 flex items-center gap-3 overflow-hidden bg-brand-red px-4 py-2.5">
      <div className="flex flex-shrink-0 items-center gap-2">
        <span className="flex items-center gap-1.5 rounded bg-white px-2.5 py-1 text-xs font-bold uppercase tracking-wider text-brand-red">
          <Zap size={12} fill="currentColor" />
          Breaking
        </span>
      </div>
      <p className="flex-1 truncate text-sm font-medium text-white">{message}</p>
      <button
        onClick={() => setDismissed(true)}
        className="flex-shrink-0 rounded p-1 text-white/80 transition-colors hover:bg-white/20 hover:text-white focus-visible-ring"
        aria-label="Dismiss breaking news"
      >
        <X size={16} />
      </button>
    </div>
  );
}
