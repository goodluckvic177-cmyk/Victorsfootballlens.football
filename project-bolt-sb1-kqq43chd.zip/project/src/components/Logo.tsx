import { Eye } from 'lucide-react';

interface LogoProps {
  className?: string;
  showText?: boolean;
  textClassName?: string;
  iconSize?: number;
}

export default function Logo({
  className = '',
  showText = true,
  textClassName = '',
  iconSize = 28,
}: LogoProps) {
  return (
    <div className={`flex items-center gap-2.5 ${className}`}>
      <div className="flex h-10 w-10 items-center justify-center rounded-md bg-brand-red">
        <Eye size={iconSize} color="#FFFFFF" strokeWidth={2.5} />
      </div>
      {showText && (
        <div className="flex flex-col leading-none">
          <span
            className={`font-display text-lg font-bold uppercase tracking-tight ${textClassName}`}
          >
            Victor's
          </span>
          <span
            className={`font-display text-[10px] font-semibold uppercase tracking-[0.15em] text-brand-red ${textClassName}`}
          >
            Football Lens
          </span>
        </div>
      )}
    </div>
  );
}
