import { PlayCircle, ArrowRight, Youtube } from 'lucide-react';
import type { VideoItem } from '@/data/content';

interface VideoSectionProps {
  videos: VideoItem[];
}

export default function VideoSection({ videos }: VideoSectionProps) {
  if (videos.length === 0) return null;

  const [mainVideo, ...restVideos] = videos;

  return (
    <section id="video" className="bg-white py-12 lg:py-16" aria-label="Video content">
      <div className="container-main">
        <div className="mb-8 flex items-end justify-between border-b-2 border-ink-black pb-4">
          <div>
            <span className="mb-1 flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-brand-red">
              <Youtube size={16} />
              Watch
            </span>
            <h2 className="font-display text-2xl font-bold uppercase tracking-tight text-ink-900 sm:text-3xl lg:text-4xl">
              Victor's Football Lens Video
            </h2>
          </div>
          <a
            href="#video"
            className="flex items-center gap-1 text-sm font-bold uppercase tracking-wider text-ink-700 transition-colors hover:text-brand-red focus-visible-ring rounded-sm"
          >
            <span className="hidden sm:inline">All Videos</span>
            <ArrowRight size={16} />
          </a>
        </div>

        <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
          <a
            href={`#video-${mainVideo.id}`}
            className="group relative flex min-h-[300px] flex-col justify-end overflow-hidden rounded-xl bg-ink-900 focus-visible-ring sm:min-h-[400px]"
          >
            <img
              src={mainVideo.thumbnail}
              alt={mainVideo.thumbnailAlt}
              loading="lazy"
              className="absolute inset-0 h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-ink-black via-ink-black/40 to-transparent" />
            <div className="absolute inset-0 flex items-center justify-center">
              <PlayCircle
                size={72}
                className="text-white drop-shadow-2xl transition-transform duration-300 group-hover:scale-110"
              />
            </div>
            <div className="absolute bottom-4 right-4 rounded bg-brand-red px-2 py-1 text-xs font-bold text-white">
              {mainVideo.duration}
            </div>
            <div className="relative z-10 p-6">
              <span className="tag tag-red mb-3">Featured Video</span>
              <h3 className="article-title text-xl text-white sm:text-2xl lg:text-3xl">
                {mainVideo.title}
              </h3>
              <p className="mt-2 max-w-lg text-sm text-paper-200">
                {mainVideo.description}
              </p>
            </div>
          </a>

          <div className="flex flex-col gap-4">
            {restVideos.map((video) => (
              <a
                key={video.id}
                href={`#video-${video.id}`}
                className="group flex gap-4 rounded-lg p-3 transition-colors hover:bg-paper-50 focus-visible-ring"
              >
                <div className="relative h-28 w-44 flex-shrink-0 overflow-hidden rounded-lg bg-ink-900">
                  <img
                    src={video.thumbnail}
                    alt={video.thumbnailAlt}
                    loading="lazy"
                    className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <PlayCircle size={32} className="text-white drop-shadow-lg" />
                  </div>
                  <div className="absolute bottom-1 right-1 rounded bg-brand-red px-1.5 py-0.5 text-[10px] font-bold text-white">
                    {video.duration}
                  </div>
                </div>
                <div className="flex flex-col justify-center">
                  <h3 className="article-title text-base text-ink-900 transition-colors group-hover:text-brand-red">
                    {video.title}
                  </h3>
                  <p className="mt-1 text-sm leading-relaxed text-paper-300 line-clamp-2">
                    {video.description}
                  </p>
                </div>
              </a>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
