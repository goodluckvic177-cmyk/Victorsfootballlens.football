import { ArrowRight, Clock } from 'lucide-react';
import type { Article } from '@/data/content';

interface FeaturedStoryProps {
  article: Article;
}

export default function FeaturedStory({ article }: FeaturedStoryProps) {
  return (
    <section id="home" className="relative bg-ink-black" aria-label="Featured story">
      <div className="container-main py-8 lg:py-12">
        <a
          href={`#article-${article.id}`}
          className="group relative flex min-h-[440px] flex-col justify-end overflow-hidden rounded-2xl sm:min-h-[520px] lg:min-h-[600px] focus-visible-ring"
        >
          <img
            src={article.image}
            alt={article.imageAlt}
            className="absolute inset-0 h-full w-full object-cover transition-transform duration-[800ms] ease-out group-hover:scale-105"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-ink-black via-ink-black/70 to-ink-black/10" />
          <div className="absolute inset-0 bg-gradient-to-r from-ink-black/50 to-transparent" />

          <div className="relative z-10 max-w-3xl p-6 sm:p-8 lg:p-12">
            <div className="mb-4 flex items-center gap-3">
              <span className="tag tag-red">{article.category}</span>
              {article.isFictional && (
                <span className="rounded-full border border-white/30 bg-white/10 px-3 py-1 text-xs italic text-white backdrop-blur-sm">
                  Fictional sample
                </span>
              )}
            </div>
            <h1 className="article-title text-3xl text-white sm:text-4xl lg:text-5xl xl:text-6xl">
              {article.title}
            </h1>
            <p className="mt-4 max-w-2xl text-sm leading-relaxed text-paper-200 sm:text-base lg:text-lg">
              {article.excerpt}
            </p>
            <div className="mt-6 flex flex-wrap items-center gap-4 text-xs text-paper-300 sm:text-sm">
              <span className="font-bold text-white">{article.author}</span>
              <span className="text-paper-300">{article.authorRole}</span>
              <span className="flex items-center gap-1">
                <Clock size={14} />
                {article.date}
              </span>
              <span className="flex items-center gap-1">
                <Clock size={14} />
                {article.readTime}
              </span>
            </div>
            <div className="mt-6 inline-flex items-center gap-2 rounded-md bg-brand-red px-6 py-3 text-sm font-bold uppercase tracking-wider text-white transition-all duration-200 group-hover:gap-3 group-hover:bg-brand-red-light">
              Read Story
              <ArrowRight size={16} />
            </div>
          </div>
        </a>
      </div>
    </section>
  );
}
