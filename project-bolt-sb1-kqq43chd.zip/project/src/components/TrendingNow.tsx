import { Flame, ArrowRight } from 'lucide-react';
import type { TrendingItem } from '@/data/content';

interface TrendingNowProps {
  items: TrendingItem[];
}

export default function TrendingNow({ items }: TrendingNowProps) {
  if (items.length === 0) return null;

  return (
    <section className="bg-ink-950 py-12 lg:py-16" aria-label="Trending now">
      <div className="container-main">
        <div className="mb-8 flex items-center gap-3">
          <Flame size={22} className="text-brand-red" />
          <h2 className="font-display text-2xl font-bold uppercase tracking-tight text-white sm:text-3xl">
            Trending Now
          </h2>
        </div>

        <div className="grid grid-cols-1 gap-px overflow-hidden rounded-xl bg-ink-800 sm:grid-cols-2">
          {items.map((item) => (
            <a
              key={item.id}
              href={`#trending-${item.id}`}
              className="group flex items-start gap-5 bg-ink-900 p-5 transition-colors duration-200 hover:bg-ink-800 focus-visible-ring"
            >
              <span className="flex-shrink-0 font-display text-4xl font-bold leading-none text-brand-red sm:text-5xl">
                {item.rank}
              </span>
              <div className="flex min-w-0 flex-col gap-1.5">
                <span className="text-xs font-bold uppercase tracking-wider text-brand-red-light">
                  {item.category}
                </span>
                <h3 className="font-display text-base font-semibold leading-snug text-white transition-colors group-hover:text-brand-red-light sm:text-lg">
                  {item.title}
                </h3>
                <span className="text-xs text-paper-300">{item.reads}</span>
              </div>
              <ArrowRight
                size={18}
                className="ml-auto hidden flex-shrink-0 self-center text-paper-300 transition-all duration-200 group-hover:translate-x-1 group-hover:text-brand-red sm:block"
              />
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}
