import { ArrowRight } from 'lucide-react';
import ArticleCard from './ArticleCard';
import type { Article } from '@/data/content';

interface LatestNewsProps {
  articles: Article[];
}

export default function LatestNews({ articles }: LatestNewsProps) {
  if (articles.length === 0) return null;

  return (
    <section className="bg-white py-12 lg:py-16" aria-label="Latest football news">
      <div className="container-main">
        <div className="mb-8 flex items-end justify-between border-b-2 border-ink-black pb-4">
          <div>
            <span className="mb-1 block text-xs font-bold uppercase tracking-widest text-brand-red">
              Fresh Off the Pitch
            </span>
            <h2 className="font-display text-2xl font-bold uppercase tracking-tight text-ink-900 sm:text-3xl lg:text-4xl">
              Latest Football News
            </h2>
          </div>
          <a
            href="#all-articles"
            className="flex items-center gap-1 text-sm font-bold uppercase tracking-wider text-ink-700 transition-colors hover:text-brand-red focus-visible-ring rounded-sm"
          >
            <span className="hidden sm:inline">View All</span>
            <ArrowRight size={16} />
          </a>
        </div>

        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {articles.map((article) => (
            <ArticleCard key={article.id} article={article} />
          ))}
        </div>
      </div>
    </section>
  );
}
