import Header from '@/components/Header';
import Footer from '@/components/Footer';
import BreakingNewsStrip from '@/components/BreakingNewsStrip';
import FeaturedStory from '@/components/FeaturedStory';
import LatestNews from '@/components/LatestNews';
import TrendingNow from '@/components/TrendingNow';
import PlayerSpotlight from '@/components/PlayerSpotlight';
import MatchCentre from '@/components/MatchCentre';
import VideoSection from '@/components/VideoSection';
import NewsletterCTA from '@/components/NewsletterCTA';
import {
  articles,
  featuredArticles,
  trendingItems,
  playerSpotlights,
  fixtures,
  videoItems,
} from '@/data/content';

export default function HomePage() {
  const [mainFeature] = featuredArticles;
  const latestNews = articles
    .filter((a) => a.id !== mainFeature.id)
    .slice(0, 6);

  return (
    <div className="flex min-h-screen flex-col bg-white">
      <Header />

      <main className="flex-1">
        <BreakingNewsStrip visible={false} />

        <FeaturedStory article={mainFeature} />

        <LatestNews articles={latestNews} />

        <TrendingNow items={trendingItems} />

        <PlayerSpotlight players={playerSpotlights} />

        <MatchCentre fixtures={fixtures} />

        <VideoSection videos={videoItems} />

        <NewsletterCTA />
      </main>

      <Footer />
    </div>
  );
}
