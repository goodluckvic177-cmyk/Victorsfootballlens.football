export type ArticleCategory =
  | 'Match Coverage'
  | 'Transfer News'
  | 'Player Stories'
  | 'Football Culture'
  | 'Video'
  | 'Analysis';

export interface Article {
  id: string;
  title: string;
  excerpt: string;
  category: ArticleCategory;
  author: string;
  authorRole: string;
  date: string;
  readTime: string;
  image: string;
  imageAlt: string;
  featured?: boolean;
  isFictional?: boolean;
}

export const categories: { label: string; value: ArticleCategory | 'All' }[] = [
  { label: 'All', value: 'All' },
  { label: 'Match Coverage', value: 'Match Coverage' },
  { label: 'Transfer News', value: 'Transfer News' },
  { label: 'Player Stories', value: 'Player Stories' },
  { label: 'Football Culture', value: 'Football Culture' },
  { label: 'Analysis', value: 'Analysis' },
  { label: 'Video', value: 'Video' },
];

export const articles: Article[] = [
  {
    id: 'a1',
    title: 'The Tactical Revolution: How Pressing Changed Modern Football',
    excerpt:
      'From Gegenpressing to high lines, we break down the systems reshaping the sport at its highest level.',
    category: 'Analysis',
    author: 'Victor Adeyemi',
    authorRole: 'Lead Analyst',
    date: 'Oct 12, 2026',
    readTime: '8 min read',
    image:
      'https://images.pexels.com/photos/30651230/pexels-photo-30651230.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    imageAlt: 'A crowded soccer stadium under bright lights at night',
    featured: true,
  },
  {
    id: 'a2',
    title: 'Rising Stars: The 16-Year-Old Redefining Midfield Play',
    excerpt:
      'A deep look at the youth academy prospect turning heads across European football.',
    category: 'Player Stories',
    author: 'Sarah Okonkwo',
    authorRole: 'Staff Writer',
    date: 'Oct 11, 2026',
    readTime: '6 min read',
    image:
      'https://images.pexels.com/photos/14030573/pexels-photo-14030573.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    imageAlt: 'Male soccer player in action on the field during a sunny day match',
    featured: true,
  },
  {
    id: 'a3',
    title: 'Match Report: A Night of Drama Under the Stadium Lights',
    excerpt:
      'A fictional account of a thrilling encounter — two goals in stoppage time turned the tie on its head.',
    category: 'Match Coverage',
    author: 'Daniel Martins',
    authorRole: 'Match Reporter',
    date: 'Oct 10, 2026',
    readTime: '5 min read',
    image:
      'https://images.pexels.com/photos/32190714/pexels-photo-32190714.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    imageAlt: 'Intense football match with two players battling for the ball amid a cheering crowd',
    featured: true,
    isFictional: true,
  },
  {
    id: 'a4',
    title: 'Transfer Window Watch: Five Moves That Could Reshape the Season',
    excerpt:
      'The January window looms. Here are the five deals that could shift the balance of power.',
    category: 'Transfer News',
    author: 'Victor Adeyemi',
    authorRole: 'Lead Analyst',
    date: 'Oct 9, 2026',
    readTime: '7 min read',
    image:
      'https://images.pexels.com/photos/11097680/pexels-photo-11097680.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    imageAlt: 'Intense soccer match showing players in motion on a grassy field',
  },
  {
    id: 'a5',
    title: 'The Culture of Ultras: Passion, Identity, and the Beautiful Game',
    excerpt:
      'Exploring how fan groups around the world shape the atmosphere that makes football unlike any other sport.',
    category: 'Football Culture',
    author: 'Sarah Okonkwo',
    authorRole: 'Staff Writer',
    date: 'Oct 8, 2026',
    readTime: '9 min read',
    image:
      'https://images.pexels.com/photos/34649361/pexels-photo-34649361.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    imageAlt: 'A crowded soccer stadium packed with enthusiastic fans during a match',
  },
  {
    id: 'a6',
    title: 'Video: Top 10 Goals of the Month — October 2026',
    excerpt:
      'From long-range stunners to team-build masterpieces, here are the finest strikes of the month.',
    category: 'Video',
    author: 'Daniel Martins',
    authorRole: 'Match Reporter',
    date: 'Oct 7, 2026',
    readTime: '4 min watch',
    image:
      'https://images.pexels.com/photos/32190710/pexels-photo-32190710.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    imageAlt: 'Dynamic shot of soccer players in action during a competitive match',
    isFictional: true,
  },
  {
    id: 'a7',
    title: 'From the Streets to the Stadium: One Player\u2019s Remarkable Journey',
    excerpt:
      'A fictional narrative tracing the path of a young talent from a local pitch to professional football.',
    category: 'Player Stories',
    author: 'Victor Adeyemi',
    authorRole: 'Lead Analyst',
    date: 'Oct 6, 2026',
    readTime: '10 min read',
    image:
      'https://images.pexels.com/photos/38092849/pexels-photo-38092849.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    imageAlt: 'Two young male soccer players sprinting during an intense outdoor match',
    isFictional: true,
  },
  {
    id: 'a8',
    title: 'The Evolution of the False Nine: A Tactical Deep Dive',
    excerpt:
      'How a positional innovation transformed attacking football and why it still matters today.',
    category: 'Analysis',
    author: 'Daniel Martins',
    authorRole: 'Match Reporter',
    date: 'Oct 5, 2026',
    readTime: '8 min read',
    image:
      'https://images.pexels.com/photos/38616004/pexels-photo-38616004.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    imageAlt: 'Football players in action during a lively game, focusing on strategy and technique',
  },
  {
    id: 'a9',
    title: 'Derby Day: When Rivalry Defines a City',
    excerpt:
      'A fictional look at what makes derby matches the most emotionally charged fixtures in football.',
    category: 'Football Culture',
    author: 'Sarah Okonkwo',
    authorRole: 'Staff Writer',
    date: 'Oct 4, 2026',
    readTime: '6 min read',
    image:
      'https://images.pexels.com/photos/35898730/pexels-photo-35898730.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    imageAlt: 'Aerial view of a night football match with an illuminated stadium full of fans',
    isFictional: true,
  },
  {
    id: 'a10',
    title: 'The Science of Set Pieces: Data Meets the Dead Ball',
    excerpt:
      'How clubs are using data analytics to turn corners and free kicks into reliable goal-scoring chances.',
    category: 'Analysis',
    author: 'Victor Adeyemi',
    authorRole: 'Lead Analyst',
    date: 'Oct 3, 2026',
    readTime: '7 min read',
    image:
      'https://images.pexels.com/photos/35579075/pexels-photo-35579075.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    imageAlt: 'Close-up image of a soccer ball resting in a goal net on a vibrant green grass field',
  },
  {
    id: 'a11',
    title: 'The Goalkeeper\u2019s Art: Reading the Game One Dive at a Time',
    excerpt:
      'A close examination of what separates great goalkeepers from good ones — positioning, reflexes, and psychology.',
    category: 'Analysis',
    author: 'Daniel Martins',
    authorRole: 'Match Reporter',
    date: 'Oct 2, 2026',
    readTime: '6 min read',
    image:
      'https://images.pexels.com/photos/32205615/pexels-photo-32205615.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    imageAlt: 'Dynamic action shot of a goalkeeper making a high save during a soccer game',
  },
  {
    id: 'a12',
    title: 'Celebrating the Game: Trophies, Tears, and the Pursuit of Glory',
    excerpt:
      'What winning means to players and fans — a reflection on the emotional weight of football\u2019s biggest prizes.',
    category: 'Football Culture',
    author: 'Sarah Okonkwo',
    authorRole: 'Staff Writer',
    date: 'Oct 1, 2026',
    readTime: '5 min read',
    image:
      'https://images.pexels.com/photos/14363874/pexels-photo-14363874.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    imageAlt: 'Group of boys celebrating a soccer tournament victory with confetti and trophy',
    isFictional: true,
  },
  {
    id: 'a13',
    title: 'The Modern Coach: Tactics, Man-Management, and the Touchline',
    excerpt:
      'How today\u2019s managers balance data-driven strategy with the human side of leading a dressing room.',
    category: 'Analysis',
    author: 'Victor Adeyemi',
    authorRole: 'Lead Analyst',
    date: 'Sep 30, 2026',
    readTime: '7 min read',
    image:
      'https://images.pexels.com/photos/30585023/pexels-photo-30585023.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    imageAlt: 'Focused soccer coach instructing players during a training session on a green field',
  },
  {
    id: 'a14',
    title: 'Youth Development: The Academies Shaping Football\u2019s Future',
    excerpt:
      'Inside the training grounds where the next generation of talent is forged.',
    category: 'Player Stories',
    author: 'Sarah Okonkwo',
    authorRole: 'Staff Writer',
    date: 'Sep 29, 2026',
    readTime: '6 min read',
    image:
      'https://images.pexels.com/photos/7187841/pexels-photo-7187841.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    imageAlt: 'A soccer player practicing drills on a sunny day on an outdoor field',
  },
];

export const featuredArticles = articles.filter((a) => a.featured);
export const latestArticles = articles.filter((a) => !a.featured);

export interface TrendingItem {
  id: string;
  rank: number;
  title: string;
  category: string;
  reads: string;
}

export const trendingItems: TrendingItem[] = [
  {
    id: 't1',
    rank: 1,
    title: 'Why the January Transfer Window Could See Record-Breaking Moves',
    category: 'Transfer News',
    reads: '42K reads',
  },
  {
    id: 't2',
    rank: 2,
    title: 'The Pressing Revolution: Which Clubs Are Leading the Charge?',
    category: 'Analysis',
    reads: '38K reads',
  },
  {
    id: 't3',
    rank: 3,
    title: 'A 16-Year-Old Prodigy Is Turning Heads Across Europe',
    category: 'Player Stories',
    reads: '35K reads',
  },
  {
    id: 't4',
    rank: 4,
    title: 'Derby Day Drama: When Rivalry Boils Over on the Pitch',
    category: 'Match Coverage',
    reads: '31K reads',
  },
  {
    id: 't5',
    rank: 5,
    title: 'The Ultras: How Fan Culture Defines the Modern Stadium Experience',
    category: 'Football Culture',
    reads: '27K reads',
  },
];

export interface PlayerSpotlight {
  id: string;
  name: string;
  role: string;
  tagline: string;
  image: string;
  imageAlt: string;
  stats: { label: string; value: string }[];
  isFictional: boolean;
}

export const playerSpotlights: PlayerSpotlight[] = [
  {
    id: 'p1',
    name: 'The Maestro',
    role: 'Attacking Midfielder',
    tagline: 'A fictional rising star redefining creativity in the final third.',
    image:
      'https://images.pexels.com/photos/30541842/pexels-photo-30541842.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    imageAlt: 'Portrait of a young soccer player in a red and white jersey in a studio setting',
    stats: [
      { label: 'Goals', value: '12' },
      { label: 'Assists', value: '18' },
      { label: 'Age', value: '19' },
    ],
    isFictional: true,
  },
  {
    id: 'p2',
    name: 'The Wall',
    role: 'Goalkeeper',
    tagline: 'A fictional shot-stopper whose reflexes have become the stuff of legend.',
    image:
      'https://images.pexels.com/photos/21222661/pexels-photo-21222661.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    imageAlt: 'Portrait of a young male football goalkeeper in a green jersey holding a soccer ball',
    stats: [
      { label: 'Clean Sheets', value: '14' },
      { label: 'Saves', value: '89' },
      { label: 'Age', value: '24' },
    ],
    isFictional: true,
  },
  {
    id: 'p3',
    name: 'The Sprinter',
    role: 'Winger',
    tagline: 'A fictional wide player blazing down the flank with pace and precision.',
    image:
      'https://images.pexels.com/photos/37044685/pexels-photo-37044685.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    imageAlt: 'Teen soccer player in blue jersey holding a soccer ball in a studio setting',
    stats: [
      { label: 'Goals', value: '8' },
      { label: 'Crosses', value: '67' },
      { label: 'Age', value: '17' },
    ],
    isFictional: true,
  },
];

export interface Fixture {
  id: string;
  homeTeam: string;
  awayTeam: string;
  competition: string;
  dateLabel: string;
  timeLabel: string;
  isFictional: boolean;
}

export const fixtures: Fixture[] = [
  {
    id: 'f1',
    homeTeam: 'Northgate FC',
    awayTeam: 'Riverside United',
    competition: 'Premier Division',
    dateLabel: 'Sat, Oct 17',
    timeLabel: '15:00',
    isFictional: true,
  },
  {
    id: 'f2',
    homeTeam: 'Eastvale SC',
    awayTeam: 'Coastal Athletic',
    competition: 'Premier Division',
    dateLabel: 'Sat, Oct 17',
    timeLabel: '17:30',
    isFictional: true,
  },
  {
    id: 'f3',
    homeTeam: 'Harbor City',
    awayTeam: 'Stonewall FC',
    competition: 'Cup Quarter-Final',
    dateLabel: 'Sun, Oct 18',
    timeLabel: '14:00',
    isFictional: true,
  },
  {
    id: 'f4',
    homeTeam: 'Meridian Town',
    awayTeam: 'Oakridge Rovers',
    competition: 'Premier Division',
    dateLabel: 'Sun, Oct 18',
    timeLabel: '16:30',
    isFictional: true,
  },
];

export interface VideoItem {
  id: string;
  title: string;
  description: string;
  thumbnail: string;
  thumbnailAlt: string;
  duration: string;
  isFictional: boolean;
}

export const videoItems: VideoItem[] = [
  {
    id: 'v1',
    title: 'Top 10 Goals of the Month — October 2026',
    description: 'From long-range stunners to team-build masterpieces, here are the finest strikes of the month.',
    thumbnail:
      'https://images.pexels.com/photos/32190710/pexels-photo-32190710.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    thumbnailAlt: 'Dynamic shot of soccer players in action during a competitive match',
    duration: '8:42',
    isFictional: true,
  },
  {
    id: 'v2',
    title: 'Tactical Breakdown: The Art of the High Press',
    description: 'A visual guide to how pressing systems work and why they dominate modern football.',
    thumbnail:
      'https://images.pexels.com/photos/30585023/pexels-photo-30585023.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    thumbnailAlt: 'Focused soccer coach instructing players during a training session',
    duration: '12:15',
    isFictional: true,
  },
  {
    id: 'v3',
    title: 'Match Highlights: A Night of Drama Under the Lights',
    description: 'Relive the fictional thriller — two stoppage-time goals that turned the tie on its head.',
    thumbnail:
      'https://images.pexels.com/photos/32190700/pexels-photo-32190700.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    thumbnailAlt: 'Dynamic action during a nighttime football match with players competing',
    duration: '5:30',
    isFictional: true,
  },
];
